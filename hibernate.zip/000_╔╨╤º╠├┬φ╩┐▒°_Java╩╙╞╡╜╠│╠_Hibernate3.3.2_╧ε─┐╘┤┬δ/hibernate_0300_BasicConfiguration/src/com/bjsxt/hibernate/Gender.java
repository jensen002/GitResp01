package com.bjsxt.hibernate;

public enum Gender {
	MALE, FEMALE
}
