package com.bjsxt.hibernate;



public class Wife {
	
	private String wifeName;
	private int age;
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
		
	public String getWifeName() {
		return wifeName;
	}
	public void setWifeName(String name) {
		this.wifeName = name;
	}
	
}
